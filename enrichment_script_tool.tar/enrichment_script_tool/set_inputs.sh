###########################################################################################################
# This file contains list of properties that will be used by script 'extract_enrichment_data_for_AMP.sh'
# Please set proper values as per your DPM and AMP configurations.
###########################################################################################################

# Details of the first ASP account
export DPM_DB_SID_1=DPM11G
export DPM_DB_USER_1=DPMPERF5SUB
export DPM_DB_PASSWORD_1=DPMPERF5SUB
export DPM_DB_HOST_1=192.168.1.215
export DPM_DB_PORT_1=1521

#export DPM_DB_SID_2=DPM11G
#export DPM_DB_USER_2=DPMPERF5SUB
#export DPM_DB_PASSWORD_2=DPMPERF5SUB
#export DPM_DB_HOST_2=192.168.1.215
#export DPM_DB_PORT_2=1521

#export DPM_DB_SID_3=DPM11G
#export DPM_DB_USER_3=DPMPERF5SUB
#export DPM_DB_PASSWORD_3=DPMPERF5SUB
#export DPM_DB_HOST_3=192.168.1.215
#export DPM_DB_PORT_3=1521

#export DPM_DB_SID_4=DPM11G
#export DPM_DB_USER_4=DPMPERF5SUB
#export DPM_DB_PASSWORD_4=DPMPERF5SUB
#export DPM_DB_HOST_4=192.168.1.215
#export DPM_DB_PORT_4=1521

#export DPM_DB_SID_5=DPM11G
#export DPM_DB_USER_5=DPMPERF5SUB
#export DPM_DB_PASSWORD_5=DPMPERF5SUB
#export DPM_DB_HOST_5=192.168.1.215
#export DPM_DB_PORT_5=1521

#export DPM_DB_SID_6=DPM11G
#export DPM_DB_USER_6=DPMPERF5SUB
#export DPM_DB_PASSWORD_6=DPMPERF5SUB
#export DPM_DB_HOST_6=192.168.1.215
#export DPM_DB_PORT_6=1521

#export DPM_DB_SID_7=DPM11G
#export DPM_DB_USER_7=DPMPERF5SUB
#export DPM_DB_PASSWORD_7=DPMPERF5SUB
#export DPM_DB_HOST_7=192.168.1.215
#export DPM_DB_PORT_7=1521

#export DPM_DB_SID_8=DPM11G
#export DPM_DB_USER_8=DPMPERF5SUB
#export DPM_DB_PASSWORD_8=DPMPERF5SUB
#export DPM_DB_HOST_8=192.168.1.215
#export DPM_DB_PORT_8=1521

# Please add as many entries of ASP accounts as per your business configuration as given above.
# So, if there is a third ASP account, you will add the following properties for the third account -
# Details of the third ASP account
# export DPM_DB_SID_N=DPMORA11G3
# export DPM_DB_USER_N=dpmusr3
# export DPM_DB_PASSWORD_N=dpmpasswd3
# export DPM_DB_HOST_N=
# export DPM_DB_PORT_N=
# export SERVICE_NAME_N=

# Details of AMP aggregation server where the output enrichment file will be copied
export TARGET_FTP_HOST=10.100.10.24
export TARGET_FTP_USER=sesoln06
export TARGET_FTP_LOCATION=/data/users/sesoln06/demo_itscom/enc_target

# Location of private key on reporting server for ssh
# This property is needed only if the copy target is on a different host.
# Currently this tool is run on amp-agg1 server so we dont need ssh key.
# export SSH_KEY_LOCATION=/data/users/sigmausr/thishost-rsync-key

# Encryption password to encrypting enrichment file
export CRYPT_PWD=test

# Retention policy for enrichment files
export PURGE_SPAN_IN_DAYS=30
