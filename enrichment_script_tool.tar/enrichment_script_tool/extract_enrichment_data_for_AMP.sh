#!/bin/bash 
#####################################################################################################################
# This script extracts subscriber information from DPM database and sends it to AMP server.
# This script is written for iTSCOM. 
# It does the following tasks -
# 1. Extract data from all DPM ASP (Application Service Provider) schemas into individual enrichment files
# 2. Merge it into single ,dat file
# 3. Encrypt this .dat file using mcrypt software to create a .enc file. 
# 4. Copy this .enc file to specified location on AMP Aggregation server.
# 5. Purge all old files (data as well as log files).
#####################################################################################################################

#set -x

THIS_DIR_NAME=`dirname $0`
chmod 775 $THIS_DIR_NAME/*

# Load configuration from set_inputs.sh
. `dirname $0`/set_inputs.sh

mkdir -p $THIS_DIR_NAME/logs
mkdir -p $THIS_DIR_NAME/data

DATA_DIR=$THIS_DIR_NAME/data
LOG_DIR=$THIS_DIR_NAME/logs

LOG_FILE_SUFFIX=`date +"%Y-%m-%d-%H"`
LOG_FILE=$LOG_DIR/extract_enrichment_data_for_AMP.${LOG_FILE_SUFFIX}.log
ENRICHMENT_FILE_SUFFIX=`date +"%Y%m%d%H%M%S"`

#echo "Current working directory is: $THIS_DIR_NAME." > $LOG_FILE 2>&1
echo "Logging all details in file $LOG_FILE with a suffix date as YYYY-MM-DD-HH." >> $LOG_FILE 2>&1

RES_ERROR=1
APP_ERROR=2

cd $THIS_DIR_NAME

echo "Starting the extraction from DPM database at `date +"%Y-%m-%d %H:%M:%S"`..." >> $LOG_FILE 2>&1


# Looping over the total ASP accounts one by one
echo "Looping over all ASP accounts given in set_inputs.sh one by one." >> $LOG_FILE 2>&1
i=1
while [ $(expr length $(eval "echo ""X$""DPM_DB_SID_$i")) -gt 1 ]
do
	CURRENT_DPM_SID=$(eval "echo ""$""DPM_DB_SID_$i")
	CURRENT_DB_USER=$(eval "echo ""$""DPM_DB_USER_$i")
	CURRENT_DB_PASSWORD=$(eval "echo ""$""DPM_DB_PASSWORD_$i")
        CURRENT_DB_HOST=$(eval "echo ""$""DPM_DB_HOST_$i")
        CURRENT_DB_PORT=$(eval "echo ""$""DPM_DB_PORT_$i")
    
	echo "Currently fetching data from DPM SID $CURRENT_DPM_SID." >> $LOG_FILE 2>&1
	
	# Calling SQL script which will run query on $CURRENT_DPM_SID and spool the output in a temporary .dat file named 'enrichment_file_part.dat'.
	sqlplus -s $CURRENT_DB_USER/$CURRENT_DB_PASSWORD@${CURRENT_DB_HOST}:$CURRENT_DB_PORT/$CURRENT_DPM_SID @${THIS_DIR_NAME}/AMP_Enrichment_Query_Production.sql
	if [ "$?" -ne "0" ];
	then
		echo "Database extract from $CURRENT_DB_USER/$CURRENT_DPM_SID failed. Please check logs." >> $LOG_FILE
		echo "APP_ERROR is : $APP_ERROR" >> $LOG_FILE 2>&1
                exit $APP_ERROR
	fi

	# Convert the file created by above SQL script into a temporary file with $CURRENT_DPM_SID as part of it
	if [ -f ${DATA_DIR}/enrichment_file_part.dat ];
	then
		mv ${DATA_DIR}/enrichment_file_part.dat $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat
		RECORD_COUNT=`wc -l $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat | awk '{print $1}'`
                # Check if nothing was found in DB
                NO_ROWS_SELECTED_CHECK=`grep -rl 'no rows selected' $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat | wc -l`
                # Also check for any ERROR in sql
                SQL_ORA_ERROR_CHECK=`grep -rl 'ORA-' $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat | wc -l`
                if [ $NO_ROWS_SELECTED_CHECK -ne "0" ];
                then
                    echo "No record found for part $i in $CURRENT_DPM_SID schema" >> $LOG_FILE 2>&1
                    cat /dev/null >$DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat 
                elif [ $SQL_ORA_ERROR_CHECK -ne "0" ];
                then
                    echo "Error in SQL, hence exiting. Please check error in file $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat."  >> $LOG_FILE 2>&1
                   #rm $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat
                    exit $APP_ERROR
                else
                    echo "Data extracted successfully from $CURRENT_DPM_SID and $RECORD_COUNT records are stored in file $DATA_DIR/enrichment_file_part_$i.$CURRENT_DPM_SID.$ENRICHMENT_FILE_SUFFIX.dat." >> $LOG_FILE 2>&1
                fi
	else
		echo "DB extract file enrichment_file_part.dat could not be found. Please check logs." >> $LOG_FILE 2>&1
		exit $APP_ERROR
	fi

	i=$[$i+1]
	
done;
echo "Extraction of enrichment information from all ASPs is done fully at `date +"%Y-%m-%d %H:%M:%S"`. Now starting to merge all individual files." >> $LOG_FILE 2>&1

# After all enrichment part files are created, concatenate them into a single final enrichment file
cat ${DATA_DIR}/enrichment_file_part*.dat > ${DATA_DIR}/amp_$ENRICHMENT_FILE_SUFFIX.dat
TOTAL_RECORD_COUNT=`wc -l ${DATA_DIR}/amp_$ENRICHMENT_FILE_SUFFIX.dat | awk '{print $1}'`
echo "Done concatenation of all individual files into ${DATA_DIR}/amp_$ENRICHMENT_FILE_SUFFIX.dat at `date +"%Y-%m-%d %H:%M:%S"`." >> $LOG_FILE 2>&1
echo "This file contains total $TOTAL_RECORD_COUNT enrichment records." >> $LOG_FILE 2>&1
echo "Now encrypting this file..." >> $LOG_FILE 2>&1
enr_file_name_cut_extn=`basename ${DATA_DIR}/amp_$ENRICHMENT_FILE_SUFFIX.dat | cut -d. -f1`
${THIS_DIR_NAME}/encpt.sh ${DATA_DIR}/$enr_file_name_cut_extn
#${THIS_DIR_NAME}/crypt $CRYPT_PWD <${DATA_DIR}/$enr_file_name_cut_extn.dat >${DATA_DIR}/$enr_file_name_cut_extn.enc >> $LOG_FILE 2>&1
if [ "$?" -ne "0" ];
then
   echo "Encryption failed. Please check logs." >> $LOG_FILE 2>&1
   exit $APP_ERROR
fi

echo "Done encrypting it. Now copying it to AMP aggregation server." >> $LOG_FILE 2>&1
echo "The final enrichment file to be copied to AMP is ${DATA_DIR}/$enr_file_name_cut_extn.enc with a suffix date as YYYYMMDDHHMMSS." >> $LOG_FILE 2>&1
if [ -f ${DATA_DIR}/$enr_file_name_cut_extn.enc ]
then
     cp ${DATA_DIR}/$enr_file_name_cut_extn.enc $TARGET_FTP_LOCATION >> $LOG_FILE 2>&1
     #rsync -avz -e "ssh -i $SSH_KEY_LOCATION" ${DATA_DIR}/$enr_file_name_cut_extn.enc $TARGET_FTP_USER@$TARGET_FTP_HOST:$TARGET_FTP_LOCATION >> $LOG_FILE 2>&1
     echo "File copied to AMP location $TARGET_FTP_LOCATION." >> $LOG_FILE 2>&1
else
     echo "Encrypted file ${DATA_DIR}/$enr_file_name_cut_extn.enc not found to copy." >> $LOG_FILE 2>&1
fi

# Move all temporary files to a temp location
mkdir -p ${DATA_DIR}/temp_files
mv ${DATA_DIR}/*part*.dat ${DATA_DIR}/temp_files

# Purging files which are older than the property PURGE_SPAN_IN_DAYS set in set_inputs.sh
echo "Now starting to purge old files at `date +"%Y-%m-%d %H:%M:%S"`." >> $LOG_FILE 2>&1

retention_date=`date +%Y%m%d -d "$PURGE_SPAN_IN_DAYS days ago"`

# Delete data files files
for file in `find $DATA_DIR/* -name 'amp_*'` ; 
do
        just_file_name=`basename $file`
	file_date=`echo $just_file_name|awk -F"." '{print $1}'|awk '{print substr($1,length($1)-13, length($1)-10)}'`
        #echo "data file date : $file_date"  >> $LOG_FILE 2>&1
	if [ $file_date -lt $retention_date ] ; then
	     rm -f $file
             #echo "File $file deleted."
        fi
done
echo "Purge successful - files under $DATA_DIR older than $PURGE_SPAN_IN_DAYS days are deleted." >> $LOG_FILE 2>&1

# Delete data/temp_files files
for file in `find $DATA_DIR/temp_files* -name 'enrichment*'` ;
do
        just_file_name=`basename $file`
        filedate=`echo $just_file_name|awk -F"." '{print $3}'`
        file_date=`echo $filedate | head -c 8`
        #echo "temp file date : $file_date"  >> $LOG_FILE 2>&1
        if [ $file_date -lt $retention_date ] ; then
             rm -f $file
             #echo "File $file deleted."
        fi
done
echo "Purge successful - files under $DATA_DIR/temp_files older than $PURGE_SPAN_IN_DAYS days are deleted." >> $LOG_FILE 2>&1


# Delete log files
for file in `find $LOG_DIR/* -name '*.log'` ; 
do
        just_file_name=`basename $file`
        filedate=`echo $just_file_name|awk -F"." '{print $2}'`
        yy=`echo $filedate | cut -d- -f1`
        mon=`echo $filedate | cut -d- -f2`
        dd=`echo $filedate | cut -d- -f3`
        file_date=$yy$mon$dd
        #echo "log file date: $file_date" >> $LOG_FILE 2>&1
	if [ $file_date -lt $retention_date ] ; then
             rm -f $file
             #echo "File $file deleted."
        fi
done
echo "Purge successful - files under $LOG_DIR older than $PURGE_SPAN_IN_DAYS days are deleted." >> $LOG_FILE 2>&1

echo "All data files and log files older than $PURGE_SPAN_IN_DAYS days purged successfully at `date +"%Y-%m-%d %H:%M:%S"`." >> $LOG_FILE 2>&1

echo "Script completed fully at `date +"%Y-%m-%d %H:%M:%S"`." >> $LOG_FILE 2>&1
