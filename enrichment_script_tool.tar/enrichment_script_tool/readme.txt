$Id: readme.txt,v 1.1 2014/04/11 16:19:55 krishnan Exp $

Patch for AMP enrichment requirement

Reference folder Location : 

BASE_DIR=/home/sigmausr/amp6/
ENRICHMENT_SCRIPT_SERVER=amp-agg1


To apply the patch,

1.Go to <BASE_DIR> location on <ENRICHMENT_SCRIPT_SERVER> .

2. extract the AMP patch tar( please use gtar xvf ) file under <BASE_DIR> location,  This will create the patch directory 
"enrichment_script_tool"

3. Set the values in set_inputs.sh as per business requirement .

For example For each ASP configure below DB credentials as below,

export DPM_DB_SID_2=DPM11G
export DPM_DB_USER_2=DPMPERF5SUB
export DPM_DB_PASSWORD_2=DPMPERF5SUB
export DPM_DB_HOST_2=192.168.1.215
export DPM_DB_PORT_2=1521 

4. Set CRON Job entry to execute the script 'extract_enrichment_data_for_AMP.sh' daily midnight at 00:00.

--Done