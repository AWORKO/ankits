set linesize 1000
set pagesize 0
set heading off
set feedback off
set verify off
set serveroutput on size 1000000
set trimspool on

--set timing on

spool ./data/enrichment_file_part.dat

SELECT   DISTINCT
         '.' || '|' ||                                         -- ACCOUNT_NAME
                      pi.userid || '|'
         ||                                                  -- ACCOUNT_NUMBER
           DECODE (subscriber.subscriptionstatus,
                   'complete', 'ACTIVE',
                   'partial', 'ACTIVE',
                   'SUSPENDED')
         || '|'
         ||                                                  -- ACCOUNT_STATUS
           '100'
         || '|'
         ||                                                         -- AUP_CAP
           '.'
         || '|'
         ||                                                            -- CITY
           '.'
         || '|'
         ||                                                           -- EMAIL
           '.'
         || '|'
         ||                                                    -- CSG_SYS_PRIN
           'RESIDENTIAL'
         || '|'
         ||                                                   -- CUSTOMER_TYPE
          UPPER (lt.displayname)                              -- SERVICE_PROVIDER
         || '|'
         || '.'
         || '|'
         || '.'                                                  -- FIBER_NODE
         || '|'
         ||                                                             -- KMA
           SUBSTR (hsd.macaddressofcm, 1, 2)
         || ':'
         || SUBSTR (hsd.macaddressofcm, 3, 2)
         || ':'
         || SUBSTR (hsd.macaddressofcm, 5, 2)
         || ':'
         || SUBSTR (hsd.macaddressofcm, 7, 2)
         || ':'
         || SUBSTR (hsd.macaddressofcm, 9, 2)
         || ':'
         || SUBSTR (hsd.macaddressofcm, 11, 2)
         || '|'
         ||                                                     -- MAC_ADDRESS
           '.'
         || '|'
         ||                                                 -- OPERATING_GROUP
           '.'
         || '|'
         ||                                                           -- PHONE
           imageparams.packagename
         || '|'
         ||                                                    -- PACKAGE_TIER
           '.'
         || '|'
         ||                                                         -- ADDRESS
           '.'
         || '|'
         ||                                                         -- SERVICE
           '.'
         || '|'
         ||                                                           -- STATE
           '.'                                                     -- ZIP_CODE
  FROM   pi,
         hsd,
         subscriber,
         imageparams,
         subs_service_to_device,
         locationtree lt
 WHERE       pi.parentref = hsd.parentref
         AND imageparams.binfilename = hsd.imagefile
         AND subs_service_to_device.subscriber_ref = pi.parentref
         AND subs_service_to_device.subscriber_ref = subscriber.recordnumber
         AND subs_service_to_device.device_id IN
                  (SELECT   deviceid                      --For CMTS IP Checks
                     FROM   docsiscmts
                    WHERE   deletestatus = 0
                            AND IPAddress IN (SELECT   ipaddress
                                                FROM   docsiscmts
                                               WHERE   deletestatus = 0))
         AND subs_service_to_device.device_type = 'DocsisCMTS'
	       AND subs_service_to_device.service_record_number=hsd.recordnumber
	       AND subs_service_to_device.service_name='HSD'
	       AND subscriber.locationid=lt.recordnumber
         AND subscriber.subscriptionstatus <> 'deleted'
         AND pi.deletestatus = 0
         AND hsd.deletestatus = 0
         AND subscriber.deletestatus = 0
         AND imageparams.deletestatus = 0
         AND subs_service_to_device.deletestatus = 0
         AND lt.PATH like '.ROOT%'
         AND lt.DELETESTATUS = 0 ;
		 
spool off;

exit;
