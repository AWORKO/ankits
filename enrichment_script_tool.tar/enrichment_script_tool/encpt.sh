
# Load configuration from set_inputs.sh
. `dirname $0`/set_inputs.sh
THIS_DIR_NAME=`dirname $0`

$THIS_DIR_NAME/crypt $CRYPT_PWD <$1.dat >$1.enc
